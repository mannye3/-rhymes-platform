<?php

return [
    App\Providers\AppServiceProvider::class,
    // App\Providers\RepositoryServiceProvider::class, // Removed repository pattern
];