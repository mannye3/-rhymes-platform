
<?php $__env->startSection('title', 'Submit Your First Book | Rhymes Platform'); ?>

<?php $__env->startSection('content'); ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between g-3">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">Submit Your First Book</h3>
            <div class="nk-block-des text-soft">
                <p>Submit your book for review and approval</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-light">
                <em class="icon ni ni-arrow-left"></em><span>Back to Dashboard</span>
            </a>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="row g-gs">
        <div class="col-lg-8">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="alert alert-primary">
                        <div class="alert-cta">
                            <div class="alert-text">
                                <h6>Important:</h6>
                                <p>Once your book is approved, you'll become an author and gain access to the full author dashboard.</p>
                            </div>
                        </div>
                    </div>
                    
                    <form action="<?php echo e(route('user.books.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="nk-block-head">
                            <h5 class="title">Book Information</h5>
                        </div>
                        
                        <div class="row gy-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="isbn">ISBN <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['isbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="isbn" name="isbn" value="<?php echo e(old('isbn')); ?>" required>
                                        <?php $__errorArgs = ['isbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="form-note-error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <div class="form-note">Enter the 13-digit ISBN of your book</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="title">Book Title <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="title" name="title" value="<?php echo e(old('title')); ?>" required>
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="form-note-error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="genre">Genre <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <select class="form-select <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="genre" name="genre" required>
                                            <option value="">Select Genre</option>
                                            <option value="Fiction" <?php echo e(old('genre') == 'Fiction' ? 'selected' : ''); ?>>Fiction</option>
                                            <option value="Non-Fiction" <?php echo e(old('genre') == 'Non-Fiction' ? 'selected' : ''); ?>>Non-Fiction</option>
                                            <option value="Mystery" <?php echo e(old('genre') == 'Mystery' ? 'selected' : ''); ?>>Mystery</option>
                                            <option value="Romance" <?php echo e(old('genre') == 'Romance' ? 'selected' : ''); ?>>Romance</option>
                                            <option value="Sci-Fi" <?php echo e(old('genre') == 'Sci-Fi' ? 'selected' : ''); ?>>Science Fiction</option>
                                            <option value="Fantasy" <?php echo e(old('genre') == 'Fantasy' ? 'selected' : ''); ?>>Fantasy</option>
                                            <option value="Biography" <?php echo e(old('genre') == 'Biography' ? 'selected' : ''); ?>>Biography</option>
                                            <option value="Business" <?php echo e(old('genre') == 'Business' ? 'selected' : ''); ?>>Business</option>
                                            <option value="Self-Help" <?php echo e(old('genre') == 'Self-Help' ? 'selected' : ''); ?>>Self-Help</option>
                                            <option value="Health" <?php echo e(old('genre') == 'Health' ? 'selected' : ''); ?>>Health</option>
                                            <option value="History" <?php echo e(old('genre') == 'History' ? 'selected' : ''); ?>>History</option>
                                            <option value="Travel" <?php echo e(old('genre') == 'Travel' ? 'selected' : ''); ?>>Travel</option>
                                        </select>
                                        <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="form-note-error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="price">Price ($) <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="number" step="0.01" min="0" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="price" name="price" value="<?php echo e(old('price')); ?>" required>
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="form-note-error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="book_type">Book Type <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <select class="form-select <?php $__errorArgs = ['book_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="book_type" name="book_type" required>
                                            <option value="">Select Type</option>
                                            <option value="physical" <?php echo e(old('book_type') == 'physical' ? 'selected' : ''); ?>>Physical Only</option>
                                            <option value="digital" <?php echo e(old('book_type') == 'digital' ? 'selected' : ''); ?>>Digital Only</option>
                                            <option value="both" <?php echo e(old('book_type') == 'both' ? 'selected' : ''); ?>>Both Physical & Digital</option>
                                        </select>
                                        <?php $__errorArgs = ['book_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="form-note-error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label" for="description">Description <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                  id="description" name="description" rows="4" required><?php echo e(old('description')); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="form-note-error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <div class="form-note">Provide a detailed description of your book</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">
                                        <em class="icon ni ni-save"></em><span>Submit Book</span>
                                    </button>
                                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-light">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="nk-block-head">
                        <h5 class="title">Submission Guidelines</h5>
                    </div>
                    <div class="nk-block">
                        <ul class="list list-sm list-checked">
                            <li>Ensure your ISBN is valid and unique</li>
                            <li>Provide an accurate and compelling description</li>
                            <li>Set a competitive price for your book</li>
                            <li>Choose the appropriate genre</li>
                            <li>Your book will be reviewed within 3-5 business days</li>
                            <li>Once approved, you'll gain full author access to the platform</li>
                        </ul>
                    </div>
                    <div class="nk-block">
                        <div class="alert alert-info">
                            <div class="alert-cta">
                                <h6>Need Help?</h6>
                                <p>Contact our support team if you need assistance with your book submission.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rhymes-platform\resources\views/user/books/create.blade.php ENDPATH**/ ?>